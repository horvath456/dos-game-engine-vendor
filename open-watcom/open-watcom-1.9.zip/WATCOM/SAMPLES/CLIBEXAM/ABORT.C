#include <stdlib.h>

void main()
  {
    int major_error = 1;

    if( major_error )
      abort();
  }
