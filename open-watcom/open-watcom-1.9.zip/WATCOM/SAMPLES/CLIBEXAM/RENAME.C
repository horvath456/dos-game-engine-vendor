#include <stdio.h>

void main()
  {
    rename( "old.dat", "new.dat" );
  }
