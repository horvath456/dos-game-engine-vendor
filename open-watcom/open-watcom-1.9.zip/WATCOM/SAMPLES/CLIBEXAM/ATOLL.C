#include <stdlib.h>

void main()
{
    long long x;

    x = atoll( "-5308948400" );
}
