#include <stdio.h>
#include <math.h>

void main()
  {
    printf( "%f %f\n", fabs(.5), fabs(-.5) );
  }
