#include <stdlib.h>
#include <malloc.h>

void main()
  {
    _heapshrink();
    system( "chdir c:\\watcomc" );
  }
