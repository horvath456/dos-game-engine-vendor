#include <math.h>

void main()
  {
    double value;
    value = cos( 3.1415278 );
  }
